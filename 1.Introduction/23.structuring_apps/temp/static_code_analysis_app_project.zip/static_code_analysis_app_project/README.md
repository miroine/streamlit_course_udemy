# static_code_analysis_app
Static Code Analysis App with Streamlit and Python
